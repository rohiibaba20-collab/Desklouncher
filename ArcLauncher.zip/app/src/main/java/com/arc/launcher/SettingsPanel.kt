package com.arc.launcher

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val PALETTE = listOf(
    0xFFFFFFFF, 0xFFFF6A3D, 0xFFFFD54F, 0xFF00E5A8, 0xFF40C4FF,
    0xFF7C4DFF, 0xFFFF4081, 0xFFFF5252, 0xFFB0BEC5, 0xFF000000
).map { it.toInt() }

@Composable
fun SettingsPanel(
    s: Settings,
    assets: Assets,
    onWall: () -> Unit,
    onFrame: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val h = LocalConfiguration.current.screenHeightDp
    fun u(b: () -> Unit) { b(); s.save() }

    Column(
        modifier
            .fillMaxWidth()
            .height((h * 0.58f).dp)
            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            .background(Color(0xF2101318))
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Settings", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            TextButton(onClick = onClose) { Text("Band karo") }
        }

        Title("Wallpaper")
        Button(onClick = onWall) { Text("Wallpaper chunein") }
        SwitchRow("Time photo ke peeche (depth effect)", s.depth) { v ->
            u { s.depth = v }
            if (v && assets.cutout == null && assets.wallpaper != null) assets.makeCutout()
        }
        if (assets.status.isNotEmpty()) Text(assets.status, color = Color(0xFF9AA4B2), fontSize = 12.sp)
        SliderRow("Andhera (dim)", s.dim, 0f..0.8f, 100f) { v -> u { s.dim = v } }

        Title("Time")
        ColorRow("Time ka rang", s.timeColor) { c -> u { s.timeColor = c } }
        SliderRow("Time ka size", s.timeSize, 40f..200f) { v -> u { s.timeSize = v } }
        SliderRow("Upar se doori %", s.timeY, 0f..0.7f, 100f) { v -> u { s.timeY = v } }
        Label("Mota-patla")
        Options(listOf("Bahut patla", "Halka", "Normal", "Mota"), s.timeWeight, s.accent) { i -> u { s.timeWeight = i } }
        Label("Jagah")
        Options(listOf("Left", "Beech"), if (s.timeCenter) 1 else 0, s.accent) { i -> u { s.timeCenter = i == 1 } }
        SwitchRow("Ghanta upar, minute neeche", s.stacked) { v -> u { s.stacked = v } }
        SwitchRow("24 ghante", s.hour24) { v -> u { s.hour24 = v } }
        SwitchRow("Tarikh dikhao", s.showDate) { v -> u { s.showDate = v } }

        Title("Chhoti photo")
        SwitchRow("Photo dikhao", s.showFrame) { v -> u { s.showFrame = v } }
        Button(onClick = onFrame) { Text("Photo chunein") }
        SliderRow("Photo ka size", s.frameSize, 60f..320f) { v -> u { s.frameSize = v } }
        Label("Shape")
        Options(listOf("Kata corner", "Narm", "Gol", "Chaukor"), s.frameShape, s.accent) { i -> u { s.frameShape = i } }
        TextButton(onClick = { u { s.frameX = 60f; s.frameY = 800f } }) { Text("Photo ko wapas laao") }

        Title("Apps aur icons")
        ColorRow("Khaas rang (accent)", s.accent) { c -> u { s.accent = c } }
        SliderRow("App naam ka size", s.arcText, 14f..32f) { v -> u { s.arcText = v } }
        SwitchRow("Icons dikhao", s.showIcons) { v -> u { s.showIcons = v } }
        SliderRow("Icon ka size", s.iconSize, 24f..72f) { v -> u { s.iconSize = v } }
        Label("Icon shape")
        Options(listOf("Gol", "Narm", "Chaukor", "Asli"), s.iconShape, s.accent) { i -> u { s.iconShape = i } }
        Text(
            "Kisi app ka alag icon: arc mein us app par lamba dabayein.",
            color = Color(0xFF9AA4B2), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
private fun Title(t: String) {
    Text(t, color = Color(0xFFFF6A3D), fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 18.dp, bottom = 4.dp))
}

@Composable
private fun Label(t: String) {
    Text(t, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    scale: Float = 1f,
    onChange: (Float) -> Unit
) {
    Column {
        Label("$label: ${(value * scale).roundToInt()}")
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun SwitchRow(label: String, v: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Color.White, fontSize = 14.sp)
        Switch(checked = v, onCheckedChange = onChange)
    }
}

@Composable
private fun Options(names: List<String>, sel: Int, accent: Int, onSel: (Int) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        names.forEachIndexed { i, n ->
            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (i == sel) Color(accent) else Color(0x22FFFFFF))
                    .clickable { onSel(i) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(n, color = if (i == sel) Color.Black else Color.White, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun ColorRow(label: String, current: Int, onChange: (Int) -> Unit) {
    var hue by remember { mutableFloatStateOf(0f) }
    Label(label)
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        PALETTE.forEach { c ->
            Box(
                Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(
                        if (c == current) 3.dp else 1.dp,
                        if (c == current) Color.White else Color(0x44FFFFFF),
                        CircleShape
                    )
                    .clickable { onChange(c) }
            )
        }
    }
    Text("Rang ghumao", color = Color(0xFF9AA4B2), fontSize = 11.sp)
    Slider(
        value = hue,
        onValueChange = {
            hue = it
            onChange(android.graphics.Color.HSVToColor(floatArrayOf(it, 0.75f, 1f)))
        },
        valueRange = 0f..360f
    )
}
