package com.arc.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val s = Settings(this)
        val assets = Assets(this).also { it.loadAll() }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { Home(s, assets, tick) }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}

@Composable
fun Home(s: Settings, assets: Assets, tick: Int) {
    val ctx = LocalContext.current
    var showSettings by remember { mutableStateOf(false) }
    var iconTarget by remember { mutableStateOf<AppInfo?>(null) }
    var pendingPkg by remember { mutableStateOf<String?>(null) }
    val apps by produceState<List<AppInfo>>(emptyList(), tick) {
        value = withContext(Dispatchers.IO) { loadApps(ctx) }
    }

    val wallPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) assets.setWallpaper(uri, s.depth)
    }
    val framePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) assets.setFrame(uri)
    }
    val iconPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val p = pendingPkg
        if (uri != null && p != null) assets.setIcon(p, uri)
    }

    BackHandler(enabled = showSettings) { showSettings = false }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // 1. wallpaper
        assets.wallpaper?.let {
            Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = s.dim)))

        // 2. time (wallpaper ke upar, insaan ke peeche)
        TimeBlock(s) { showSettings = true }

        // 3. kata hua insaan time ke upar
        val cut = assets.cutout
        if (s.depth && cut != null) {
            Image(cut, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }

        // 4. chhoti photo
        if (s.showFrame) FrameView(s, assets) { framePicker.launch("image/*") }

        // 5. apps ka arc
        ArcList(
            apps, s, assets,
            onOpen = { openApp(ctx, it.pkg) },
            onLong = { iconTarget = it },
            modifier = Modifier.fillMaxHeight().fillMaxWidth(0.62f).align(Alignment.CenterEnd)
        )

        Text(
            "⚙",
            fontSize = 26.sp,
            color = Color.White.copy(alpha = 0.8f),
            modifier = Modifier
                .align(Alignment.BottomStart)
                .navigationBarsPadding()
                .padding(20.dp)
                .clickable { showSettings = true }
        )

        if (showSettings) {
            SettingsPanel(
                s, assets,
                onWall = { wallPicker.launch("image/*") },
                onFrame = { framePicker.launch("image/*") },
                onClose = { showSettings = false },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }

    iconTarget?.let { t ->
        AlertDialog(
            onDismissRequest = { iconTarget = null },
            title = { Text(t.label) },
            text = { Text("Is app ka icon badlein?") },
            confirmButton = {
                TextButton(onClick = {
                    pendingPkg = t.pkg
                    iconTarget = null
                    iconPicker.launch("image/*")
                }) { Text("Naya icon chunein") }
            },
            dismissButton = {
                TextButton(onClick = {
                    assets.resetIcon(t.pkg)
                    iconTarget = null
                }) { Text("Original icon") }
            }
        )
    }
}

@Composable
fun TimeBlock(s: Settings, onLong: () -> Unit) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(5000)
        }
    }
    val sh = LocalConfiguration.current.screenHeightDp
    val hh = now.format(DateTimeFormatter.ofPattern(if (s.hour24) "HH" else "hh"))
    val mm = now.format(DateTimeFormatter.ofPattern("mm"))
    val col = Color(s.timeColor)
    val weight = listOf(FontWeight.Thin, FontWeight.Light, FontWeight.Normal, FontWeight.Bold)[s.timeWeight]
    val st = TextStyle(
        color = col,
        fontSize = s.timeSize.sp,
        fontWeight = weight,
        fontFamily = FontFamily.SansSerif,
        letterSpacing = (-2).sp,
        lineHeight = (s.timeSize * 0.95f).sp
    )
    Column(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .offset(y = (sh * s.timeY).dp)
            .padding(horizontal = 22.dp)
            .pointerInput(Unit) { detectTapGestures(onLongPress = { onLong() }) },
        horizontalAlignment = if (s.timeCenter) Alignment.CenterHorizontally else Alignment.Start
    ) {
        if (s.stacked) {
            Text(hh, style = st)
            Text(mm, style = st)
        } else {
            Text("$hh:$mm", style = st)
        }
        if (s.showDate) {
            Text(
                now.format(DateTimeFormatter.ofPattern("EEE, dd MMM")).uppercase(),
                color = col.copy(alpha = 0.75f),
                fontSize = 14.sp,
                letterSpacing = 2.sp
            )
        }
    }
}

@Composable
fun FrameView(s: Settings, assets: Assets, onPick: () -> Unit) {
    val shape = when (s.frameShape) {
        0 -> CutCornerShape(topEnd = 28.dp)
        1 -> RoundedCornerShape(24.dp)
        2 -> CircleShape
        else -> RectangleShape
    }
    val w = s.frameSize.dp
    val h = if (s.frameShape == 2) w else (s.frameSize * 1.25f).dp
    Box(
        Modifier
            .offset { IntOffset(s.frameX.roundToInt(), s.frameY.roundToInt()) }
            .size(w, h)
            .clip(shape)
            .background(Color(0x33FFFFFF))
            .border(1.dp, Color(0x55FFFFFF), shape)
            .pointerInput(Unit) {
                detectDragGestures(onDragEnd = { s.save() }) { change, d ->
                    change.consume()
                    s.frameX += d.x
                    s.frameY += d.y
                }
            }
            .clickable { onPick() },
        contentAlignment = Alignment.Center
    ) {
        val img = assets.frame
        if (img != null) {
            Image(img, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text("📷\nphoto lagao", color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
    }
}
