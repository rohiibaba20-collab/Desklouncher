package com.arc.launcher

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class Settings(ctx: Context) {
    private val sp = ctx.getSharedPreferences("arc", Context.MODE_PRIVATE)

    // Time
    var timeColor by mutableIntStateOf(sp.getInt("timeColor", 0xFFFFFFFF.toInt()))
    var timeSize by mutableFloatStateOf(sp.getFloat("timeSize", 96f))
    var timeWeight by mutableIntStateOf(sp.getInt("timeWeight", 1))
    var timeY by mutableFloatStateOf(sp.getFloat("timeY", 0.10f))
    var timeCenter by mutableStateOf(sp.getBoolean("timeCenter", false))
    var stacked by mutableStateOf(sp.getBoolean("stacked", true))
    var hour24 by mutableStateOf(sp.getBoolean("hour24", false))
    var showDate by mutableStateOf(sp.getBoolean("showDate", true))

    // Wallpaper
    var depth by mutableStateOf(sp.getBoolean("depth", true))
    var dim by mutableFloatStateOf(sp.getFloat("dim", 0.15f))

    // Photo frame
    var showFrame by mutableStateOf(sp.getBoolean("showFrame", true))
    var frameSize by mutableFloatStateOf(sp.getFloat("frameSize", 120f))
    var frameShape by mutableIntStateOf(sp.getInt("frameShape", 0))
    var frameX by mutableFloatStateOf(sp.getFloat("frameX", 60f))
    var frameY by mutableFloatStateOf(sp.getFloat("frameY", 800f))

    // Arc and icons
    var accent by mutableIntStateOf(sp.getInt("accent", 0xFFFF6A3D.toInt()))
    var arcText by mutableFloatStateOf(sp.getFloat("arcText", 22f))
    var iconSize by mutableFloatStateOf(sp.getFloat("iconSize", 44f))
    var iconShape by mutableIntStateOf(sp.getInt("iconShape", 1))
    var showIcons by mutableStateOf(sp.getBoolean("showIcons", true))

    fun save() {
        sp.edit()
            .putInt("timeColor", timeColor)
            .putFloat("timeSize", timeSize)
            .putInt("timeWeight", timeWeight)
            .putFloat("timeY", timeY)
            .putBoolean("timeCenter", timeCenter)
            .putBoolean("stacked", stacked)
            .putBoolean("hour24", hour24)
            .putBoolean("showDate", showDate)
            .putBoolean("depth", depth)
            .putFloat("dim", dim)
            .putBoolean("showFrame", showFrame)
            .putFloat("frameSize", frameSize)
            .putInt("frameShape", frameShape)
            .putFloat("frameX", frameX)
            .putFloat("frameY", frameY)
            .putInt("accent", accent)
            .putFloat("arcText", arcText)
            .putFloat("iconSize", iconSize)
            .putInt("iconShape", iconShape)
            .putBoolean("showIcons", showIcons)
            .apply()
    }
}
