package com.arc.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.exifinterface.media.ExifInterface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import java.io.File
import kotlin.math.max

class Assets(private val ctx: Context) {
    var wallpaper by mutableStateOf<ImageBitmap?>(null)
    var cutout by mutableStateOf<ImageBitmap?>(null)
    var frame by mutableStateOf<ImageBitmap?>(null)
    var status by mutableStateOf("")
    val icons = mutableStateMapOf<String, ImageBitmap>()

    private fun file(n: String) = File(ctx.filesDir, n)

    private fun read(f: File): ImageBitmap? =
        if (f.exists()) BitmapFactory.decodeFile(f.path)?.asImageBitmap() else null

    fun loadAll() {
        wallpaper = read(file("wallpaper.jpg"))
        cutout = read(file("cutout.png"))
        frame = read(file("frame.jpg"))
        File(ctx.filesDir, "icons").listFiles()?.forEach { f ->
            read(f)?.let { icons[f.nameWithoutExtension] = it }
        }
    }

    private fun decode(uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val cr = ctx.contentResolver
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var sample = 1
            while (max(o.outWidth, o.outHeight) / sample > maxSide * 2) sample *= 2
            val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                ?: return null
            val deg = cr.openInputStream(uri)?.use { s ->
                when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90f
                    3 -> 180f
                    8 -> 270f
                    else -> 0f
                }
            } ?: 0f
            val sc = maxSide.toFloat() / max(bmp.width, bmp.height)
            val m = Matrix()
            if (sc < 1f) m.postScale(sc, sc)
            if (deg != 0f) m.postRotate(deg)
            if (m.isIdentity) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        } catch (e: Exception) {
            null
        }
    }

    private fun write(b: Bitmap, name: String, png: Boolean) {
        file(name).outputStream().use {
            b.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 92, it)
        }
    }

    fun setWallpaper(uri: Uri, depth: Boolean) {
        val b = decode(uri, 1280)
        if (b == null) { status = "Photo nahi khuli"; return }
        write(b, "wallpaper.jpg", false)
        wallpaper = b.asImageBitmap()
        file("cutout.png").delete()
        cutout = null
        if (depth) makeCutout(b)
    }

    fun makeCutout(b: Bitmap? = null) {
        val src = b ?: BitmapFactory.decodeFile(file("wallpaper.jpg").path) ?: return
        status = "Cutout ban raha hai..."
        val seg = SubjectSegmentation.getClient(
            SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
        )
        seg.process(InputImage.fromBitmap(src, 0))
            .addOnSuccessListener { r ->
                val fg = r.foregroundBitmap
                if (fg != null) {
                    write(fg, "cutout.png", true)
                    cutout = fg.asImageBitmap()
                    status = "Cutout tayyar"
                } else {
                    status = "Photo mein koi insaan/cheez nahi mili"
                }
                seg.close()
            }
            .addOnFailureListener {
                status = "Cutout nahi bana (Google Play services aur pehli baar internet chahiye)"
                seg.close()
            }
    }

    fun setFrame(uri: Uri) {
        val b = decode(uri, 600) ?: return
        write(b, "frame.jpg", false)
        frame = b.asImageBitmap()
    }

    fun setIcon(pkg: String, uri: Uri) {
        val b = decode(uri, 192) ?: return
        val dir = File(ctx.filesDir, "icons").apply { mkdirs() }
        File(dir, "$pkg.png").outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        icons[pkg] = b.asImageBitmap()
    }

    fun resetIcon(pkg: String) {
        File(File(ctx.filesDir, "icons"), "$pkg.png").delete()
        icons.remove(pkg)
    }
}
