package com.arc.launcher

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

@Composable
fun ArcList(
    apps: List<AppInfo>,
    s: Settings,
    assets: Assets,
    onOpen: (AppInfo) -> Unit,
    onLong: (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val stepPx = with(density) { 64.dp.toPx() }
    val rowH = with(density) { 52.dp.toPx() }
    val radius = with(density) { 330.dp.toPx() }
    val maxShift = with(density) { 170.dp.toPx() }
    val anim = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val maxIdx = (apps.size - 1).coerceAtLeast(0).toFloat()

    BoxWithConstraints(
        modifier.pointerInput(apps.size) {
            detectVerticalDragGestures(
                onDragEnd = { scope.launch { anim.animateTo(anim.value.roundToInt().toFloat()) } },
                onDragCancel = { scope.launch { anim.animateTo(anim.value.roundToInt().toFloat()) } }
            ) { change, dy ->
                change.consume()
                scope.launch { anim.snapTo((anim.value - dy / stepPx).coerceIn(0f, maxIdx)) }
            }
        }
    ) {
        val cy = constraints.maxHeight * 0.60f
        apps.forEachIndexed { i, app ->
            val dd = i - anim.value
            if (abs(dd) < 4.6f) {
                val focused = abs(dd) < 0.5f
                val x = min(dd * dd * stepPx * stepPx / (2 * radius), maxShift)
                val sc = max(0.62f, 1f - abs(dd) * 0.16f)
                val al = max(0f, 1f - abs(dd) * 0.22f)
                Row(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(end = 20.dp)
                        .height(52.dp)
                        .graphicsLayer {
                            translationY = cy + dd * stepPx - rowH / 2
                            translationX = x
                            scaleX = sc
                            scaleY = sc
                            alpha = al
                            transformOrigin = TransformOrigin(1f, 0.5f)
                        }
                        .pointerInput(i, focused) {
                            detectTapGestures(
                                onTap = {
                                    if (focused) onOpen(app)
                                    else scope.launch { anim.animateTo(i.toFloat()) }
                                },
                                onLongPress = { onLong(app) }
                            )
                        },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        app.label,
                        color = if (focused) Color(s.accent) else Color.White,
                        fontSize = s.arcText.sp,
                        fontWeight = if (focused) FontWeight.SemiBold else FontWeight.Light,
                        maxLines = 1,
                        style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.7f), blurRadius = 10f))
                    )
                    if (s.showIcons) AppIcon(app, s, assets)
                }
            }
        }
    }
}

@Composable
fun AppIcon(app: AppInfo, s: Settings, assets: Assets) {
    val img = assets.icons[app.pkg] ?: app.icon
    val shape = when (s.iconShape) {
        0 -> CircleShape
        1 -> RoundedCornerShape((s.iconSize * 0.3f).dp)
        else -> RoundedCornerShape(0.dp)
    }
    val m = Modifier.size(s.iconSize.dp)
    Image(
        bitmap = img,
        contentDescription = null,
        modifier = if (s.iconShape == 3) m else m.clip(shape),
        contentScale = if (s.iconShape == 3) ContentScale.Fit else ContentScale.Crop
    )
}
